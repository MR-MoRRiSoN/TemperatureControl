#include "Arduino.h"
#include <WiFi.h>
#include <DNSServer.h>


//
//
//  Install these all libraries to make the project work.
//
//
#include <ESPAsyncWebServer.h>
#include <WebSocketsServer.h>
#include <ArduinoJson.h>
#include <EEPROM.h>



class credentials {
  public:
  
  bool credentials_get();
  
  void setupAP(char* softap_ssid, char* softap_pass);
  void server_loops();
  void Erase_eeprom();
  
  String EEPROM_Config();
  String EmailOfServer();
  String PasswordOfServer();
  
  private:
  bool _testWifi(void);
  void _launchWeb(void);
  void _createWebServer(void);
  String ssid = "";
  String pass = "";
 
};
